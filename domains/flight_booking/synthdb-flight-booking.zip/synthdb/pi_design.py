"""Design and review a new domain in separate, sequential Pi sessions."""
import argparse
from contextlib import closing
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import subprocess


def ask(prompt):
    reply = subprocess.run(["pi", "--no-session", "--no-tools", "--print"], input=prompt,
                           text=True, capture_output=True, check=True, timeout=900)
    return json.loads(reply.stdout)


SKILL = Path(__file__).parent / ".agents/skills/text2sql-domain-review/SKILL.md"


def target_questions(brief):
    targets = {}
    for qid, question in re.findall(r"^ *(?:- )?\[(Q[0-9]+)\] *(.+)$", brief, re.MULTILINE):
        if qid in targets:
            raise ValueError(f"Duplicate brief ID {qid}")
        ordered = question.startswith("[ordered] ")
        text = question.removeprefix("[ordered] ").strip()
        if not text:
            raise ValueError(f"Empty target question {qid}")
        targets[qid] = {"question": text, "ordered": ordered}
    if not targets:
        raise ValueError("List the brief's target questions as [Q1] Question text, one per line.")
    return targets


def verify(schema, review, targets):
    checks = review["checks"]
    if sorted(c["id"] for c in checks) != sorted(targets):
        raise ValueError("Review must cover each brief ID exactly once")
    for check in checks:
        if check["question"] != targets[check["id"]]["question"]:
            raise ValueError(f"Question changed for {check['id']}")
    with closing(sqlite3.connect(":memory:")) as db:
        db.execute("PRAGMA foreign_keys=ON")
        db.executescript(schema)
        tables = db.execute("SELECT count(*) FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()[0]
        if not 10 <= tables <= 40:
            raise ValueError(f"Found {tables} domain tables")
        db.executescript(review["fixture_sql"])
        if db.execute("PRAGMA foreign_keys").fetchone() != (1,) or db.execute("PRAGMA foreign_key_check").fetchall():
            raise ValueError("Foreign-key validation failed")
        if not review["checks"] or not review["invalid_inserts"]:
            raise ValueError("Reviewer must supply positive and negative checks")
        for probe in review["invalid_inserts"]:
            sql = probe["sql"]
            try:
                db.execute(sql)
            except sqlite3.IntegrityError as exc:
                if exc.sqlite_errorname == probe["constraint"] == "SQLITE_CONSTRAINT_FOREIGNKEY":
                    continue
                raise ValueError(f"Unexpected constraint: {exc.sqlite_errorname}") from exc
            raise ValueError(f"Constraint failed to reject {sql}")
        db.execute("PRAGMA query_only=ON")
        for check in review["checks"]:
            def compare_rows(values):
                rows = list(map(tuple, values))
                return rows if targets[check["id"]]["ordered"] else sorted(rows, key=repr)

            rows = compare_rows(check["rows"])
            gold = db.execute(check["sql"])
            width = len(gold.description)
            if compare_rows(gold) != rows:
                raise ValueError(check["question"])
            wrong = db.execute(check["wrong_sql"])
            if len(wrong.description) != width or not check["witness"].strip():
                raise ValueError("Counterexample requires matching columns and a fixture witness")
            if compare_rows(wrong) == rows:
                raise ValueError("Fixture misses wrong query: " + check["question"])


def design(brief, output, rounds):
    targets = target_questions(brief)
    rules = SKILL.read_text()
    output.mkdir(parents=True, exist_ok=False)
    feedback = ""
    for number in range(1, rounds+1):
        folder = output / f"round-{number}"
        folder.mkdir()
        author = ask(f"""You author SQLite domain designs. Return only JSON with schema_sql and
domain_markdown strings. Implement 10-40 domain tables. Document grain, keys, relationships,
assumptions and questions. Use only SQLite DDL. Brief: {brief}
Project rules: {rules}
Previous design, reviewer findings, and execution feedback: {feedback}""")
        schema = author["schema_sql"]
        (folder/"schema.sql").write_text(schema)
        (folder/"DOMAIN.md").write_text(author["domain_markdown"])
        review = ask(f"""Independently review this design against the original brief.
Return only JSON with findings (array of blocking issues), fixture_sql (handwritten INSERTs),
checks (one per target ID, with id, verbatim question, sql, literal rows, wrong_sql and witness),
and invalid_inserts (objects with sql and constraint SQLITE_CONSTRAINT_FOREIGNKEY). Include edge cases.
For ordered targets supply rows in the requested sequence. Derive literal answers by hand. Brief: {brief}
Frozen targets: {json.dumps(targets)}
Project rules: {rules}
Frozen design: {json.dumps(author)}""")
        (folder/"review.json").write_text(json.dumps(review, indent=2))
        try:
            if review["findings"] != []:
                raise ValueError(str(review["findings"]))
            verify(schema, review, targets)
        except (ValueError, sqlite3.Error, KeyError, TypeError) as exc:
            (folder/"findings.txt").write_text(str(exc))
            feedback = json.dumps([author, review, str(exc)])
            continue
        proof = {"round": number, "question_ids": list(targets), "schema_sha256": hashlib.sha256(schema.encode()).hexdigest()}
        (output/"accepted.json").write_text(json.dumps(proof, indent=2))
        return
    raise SystemExit("Unresolved review. Inspect the final round's findings.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("brief", type=Path)
    parser.add_argument("new_directory", type=Path)
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()
    design(args.brief.read_text(), args.new_directory, args.rounds)
